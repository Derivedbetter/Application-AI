# Install dependencies
import sys  # used to stop the application on exit
import time  # used for time based functions
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator  # Sets up the Authenticator for IBM text to speech
import speech_recognition as sr  # dependency for google speech recognition
import pyttsx3  # non-cloud based speech to text engine
import PyPDF2  # dependency for reading pdf files
from ibm_watson import TextToSpeechV1  # dependency for IBM watson to function
import vlc  # plays mp3 file from text to speech


class Menu:
    # default constructor

    def __init__(self):  # this defines and sets up menu
        self.__title = '----------------------   Main Menu   ----------------------'
        self.__description1 = 'This application will demonstrate various APIs for Text-to-Speech and Speech-to-Text.'
        self.__description2 = 'Some of these APIs perform in cloud processing while others do not.'
        self.__option_one = '          Enter a new sentence to play with!'
        self.__option_two = '          Use IBM Watson to hear your sentence aloud!'
        self.__option_three = '          Convert your speech to text in real time using Google!'
        self.__option_four = '          Listen to a story aloud from a PDF! Be patient it is a little long'
        self.__option_five = '          Quit this awesome Application...yuk'
        self.__exit_input = 5

    # get / set functions
    def get_title(self):  # defines title
        return self.__title

    def set_title(self, title):  # sets title
        self.__title = title

    def get_description1(self):  # defines first line of the description
        return self.__description1

    def set_description1(self, description1):  # sets the first line of description
        self.__description1 = description1

    def get_description2(self):  # defines second line of description
        return self.__description2

    def set_description2(self, description2):  # sets second line of description
        self.__description2 = description2

    def get_option_one(self):  # defines option 1
        return self.__option_one

    def set_option_one(self, option):  # sets option 1
        self.__option_one = option

    def get_option_two(self):  # defines option 2
        return self.__option_two

    def set_option_two(self, option):  # sets option 2
        self.__option_two = option

    def get_option_three(self):  # defines option 3
        return self.__option_three

    def set_option_three(self, option):  # sets option 3
        self.__option_three = option

    def get_option_four(self):  # defines option 4
        return self.__option_four

    def set_option_four(self, option):  # sets option 4
        self.__option_four = option

    def get_option_five(self):  # defines option 5
        return self.__option_five

    def set_option_five(self, option):  # sets option 5
        self.__option_five = option

    def get_exit_input(self):  # defines exit input
        return self.__exit_input

    def set_exit_input(self, input):  # sets exit input
        self.__exit_input = input

    # object display function that shows the menu options
    def __str__(self):
        # display the menu with a formatted string when calling the object
        menu_string = '{}\n {}\n {}\n1. {}\n2. {}\n3. {}\n4. {}\n5. {}\n'.format(self.__title, self.__description1,
                                                                       self.__description2,
                                                                       self.__option_one,
                                                                       self.__option_two,
                                                                       self.__option_three,
                                                                       self.__option_four,
                                                                       self.__option_five,
                                                                       self.__exit_input)
        return menu_string


# class for validating input
class Validator:
    # default constructor
    def __init__(self):
        self.__valid = False  # this block of code sets the start and finish of the validator
        self.__start = 1
        self.__end = 5

    #  the following code pieces are the get / set functions for the validator
    def get_valid(self):
        return self.__valid

    def set_valid(self, is_valid):
        self.__valid = is_valid

    def get_start(self):
        return self.__start

    def set_start(self, first):
        self.__start = first

    def get_end(self):
        return self.__end

    def set_end(self, last):
        self.__end = last

    # validation function
    def validate(self, integer):
        self.set_valid(False)
        # make sure the user has entered an integer.
        try:  # this block of code verifies that the data input is within the menu range
            option = int(integer)
            # make sure it's inside the range of options.
            if option < self.get_start() or option > self.get_end():
                print('')
                print('That number is not one of your choices.')
            else:
                self.set_valid(True)  # if a valid choice is made this allows the user to move forward
        # This is exception handling if the user puts something other than an integer
        except ValueError:
            print('')
            print('That is not even an integer. Try again please.')
        print('')
        return self.get_valid()  # returns the user back to menu choices to input a valid number

    def __str__(self):
        validator_string = 'Valid: {}\nStart: {}\nEnd: {}'.format(self.__valid, self.__start, self.__end)
        return validator_string


def main():
    main_sentence = "You have not entered a sentence yet, but you can use this one if you would like to!"
    # set up main menu
    main_menu = Menu()
    main_validator = Validator()
    keep_going = True
    main_validator.set_valid(False)
    # stop if user enters the exit choice.
    while keep_going:
        # validate the input.
        if main_validator.get_valid() == False:
            # display the main menu and prompt for choice.
            print(main_menu)
            print('Your silly Sentence:', main_sentence)
            print('')
            validate_option: str = input('Enter number (1-5) for choice: ')
            main_validator.validate(validate_option)
        menu_option = int(validate_option)
        # determine which function to run based on user input. if they enter 5, application will quit.
        if menu_option == 1:
            main_sentence = ttsSentence()
            main_validator.set_valid(False)
        elif menu_option == 2:
            main_sentence = IBMTextToSpeech(main_sentence)
            main_validator.set_valid(False)
        elif menu_option == 3:
            GoogleTTS()
            main_validator.set_valid(False)
        elif menu_option == 4:
            PDFReader()
            main_validator.set_valid(False)
        elif menu_option == 5:
            time.sleep(2)
            quit_answer = input("Wow. We are having so much fun. Would you like to keep playing (Y or N)? ")
            if quit_answer.upper() == "N":  # turns user input to upper and checks for N to quit
                keep_going = False
                Exit()
            elif quit_answer.upper() == "Y":
                print("Awesome, let's do this!")  # this block converts user input to upper and checks for Y
                keep_going = True  # if Y is entered, user is taken back to main menu
                main()

            else:
                print('That is not a valid option. Please choose Y or N.')


class WriteNewTTSentence:
    def __init__(self, tts_sentence):
        try:
            new_file = open('new_ttsSentence.txt', 'w')  # this block is a try attempt to create a new text file
            new_file.write(tts_sentence + '\n')
            new_file.close()
            print('')
        except Exception as err:  # exception handling for file access problems
            print(err)


class BuildTTSFile(WriteNewTTSentence):
    def __init__(self, main_sentence, pretext, result):
        WriteNewTTSentence.__init__(self, main_sentence)
        try:
            text_file = open('buildTTS_file.txt', 'w')
            text_file.write('{}\n{}\n'.format(pretext, main_sentence))  # this block is a try attempt to create a new
            # text file
            text_file.close()
            print(str(pretext))
            # the following block of code attempts to create the MP3 file
            tts_audio = open('tts_audio_file.mp3', 'wb')
            tts_audio.write(result.content)
            p = vlc.MediaPlayer('tts_audio_file.mp3')  # opens the MP3 file in VLC media player and plays the sentence
            p.play()
            print(main_sentence)
            print('')
        except Exception as err:  # exception handling for file access problems
            print(err)


class BuildSpeechTT:
    def __init__(self):
        # sets variables for the speech recognition engine
        r = sr.Recognizer()
        m = sr.Microphone()
        print('Okay, take a deep breath and please speak your sentence/words/poem!')
        with m as source:
            # read the audio data from the default microphone
            audio_data = r.record(source, duration=10)
        print('I heard you. Let me figure out what you said...')
        # convert speech to text
        try:
            text = r.recognize_google(audio_data)
            if str is bytes:  # this version of Python uses bytes for strings (Python 2)
                print(u'I think you said: "{}"'.format(text).encode("utf-8"))
            else:  # this version of Python uses unicode for strings (Python 3+)
                print('I think you said: "{}"'.format(text))
        except sr.UnknownValueError:  # exception handling if the engine does not "hear" anything
            print("Oops! I didn't quite hear you!")
        except sr.RequestError as e:
            print("Ugh! Google isn't cooperating right now!; {0}".format(e))  # exception handling if Google can't be
            # reached
        try:  # tries to create a text file
            tts_file = open('text.txt', 'w')
            tts_file.write('you said: "{}"'.format(text))
            tts_file.close()
        except Exception as err:
            print(err)


class buildPDFtext():
    def __init__(self, text):
        try:
            pos_file = open('pdf_file.txt', 'w')
            pos_file.write('{}\n'.format(text))
            pos_file.close()
            print(text)
        except Exception as err:  # exception handling for file access problems
            print(err)


class Exit:
    def __init__(self):
        sentence = open('new_ttsSentence.txt', 'r')
        list_sentence = sentence.read()
        tts = open('buildTTS_file.txt.', 'r')  # these codes defines the variables to access the created text files
        list_tts = tts.read()
        stt = open('text.txt', 'r')
        list_stt = stt.read()
        your_history = [list_sentence, list_tts, list_stt]  # places text file variables in a list
        print('Here are the most recent play data: ')
        print('')
        print('The most recent sentence and other data is: ')
        print(*your_history, sep="\n")  # these print statements print the list of what has been done
        print('')
        print("Have an awesome day. Play again any time!")
        sys.exit()  # exits the program


# Is called when the user decides to change the sentence that they would like to hear.
def ttsSentence():
    tts_sentence = input('Please enter a new sentence to play with: ')
    WriteNewTTSentence(tts_sentence)  # calls the class to write the new sentence
    return tts_sentence


# Check the spelling of the user's sentence.
def IBMTextToSpeech(main_sentence):
    url = 'https://api.us-south.text-to-speech.watson.cloud.ibm.com/instances/a93e86cb-aefd-4c75-8aae-61a9ea25e286'
    api_key = 'pUW3PaYvjAwQZuGSccqlX8CrdwgyaTdiOzu4DcIufJDO'  # defines the URL and API key for IBM watson
    authenticator = IAMAuthenticator(api_key)
    tts = TextToSpeechV1(authenticator=authenticator)  # defines the tts engine
    tts.set_service_url(url)
    # defines the result variable that is sent to the BuildTTSFile class
    result = tts.synthesize(main_sentence, accept='audio/mp3', voice='en-US_MichaelV3Voice').get_result()
    pretext = 'Listen carefully:)'
    BuildTTSFile(main_sentence, pretext, result)  # calls the BuildTTSFile class and passes the parameters
    return main_sentence


def GoogleTTS():
    BuildSpeechTT()  # calls the BuildSpeechTT class
    return


def PDFReader():
    # path of the PDF file
    try:
        path = open('Reap What You Sow.pdf', 'rb')

        # creating a PdfFileReader object
        pdfReader = PyPDF2.PdfFileReader(path)
        # the page with which you want to start
        # this will read the page of 25th page.
        from_page = pdfReader.getPage(1)
        # extracting the text from the PDF
        text = from_page.extractText()
        # reading the text
        speak = pyttsx3.init()  # sets the variable for the pyttsx3 engine
        speak.say(text)  # has the engine read the text
        speak.runAndWait()  # runs the engine and waits
        buildPDFtext(text)  # calls the class to build the pfd.text
    except Exception as err:  # exception handling for file access problems
        print(err)
    return text


main()  #calls the main method
